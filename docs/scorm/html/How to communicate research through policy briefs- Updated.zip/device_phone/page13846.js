PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":650,"bgColor":"#ffffff"}
,
"button4670":{"x":51,"y":607,"w":80.000000,"h":26.000000,"stylemods":[{"sel":"div.button4670Text","decl":" { position:absolute; left:4px; top:3px; width:72px; height:20px;}"},{"sel":"span.button4670Text","decl":" { display:table-cell; position:relative; width:72px; height:20px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAAAaCAYAAAAg0tunAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGPSURBVGhD7ZaLbcMwDES9j1fJKB2kg2ROt/fUoyDJHxiJXSAAH0BY/Oho0Y6RKUmSJEmSJEmSG1iW5fEzoNiX07uo7PtMXaDaWfb861B6PGUPpz8XDsFh7N6C9GcPrQ6M2N19/wUO9e5BNJvDtxH9o/xHczRABoPZ7fwYGqZ1Rf5cihv24i0qQTvoetLDbqdFXMZnoex1rPtUEAvkbvZ4CzXrvoE0d6qAL+NGu0GrtB6sXY8oHj/f3QGyH2Pd1G9qO1cHaL9+GqjH7FaItTpaX/MNRgQxu5twk6C6OgS5pwYI496RMY8Wmqy5ttptLXHZ+MDjhWBfq1nfyoD9Tr8ODRG3u4K8+708QPSpsbti1EYr6kfttpa4bPPerUFtecuoI1aSV0IDxO2uiJugOWuHu4OxxkpiA/azN+pBa36qdUixdrzWtjmvTw0QyIUO13bvZUhw9T9QxGG6p0Y8clwjx02xCVgTGyEu2/0fqFAZjik9gBrH2BMPYneASm/qAPWOF/CdSpIkSZIkSZKGafoFOAUyn0EkC0MAAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAAAaCAYAAAAg0tunAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGPSURBVGhD7ZaLbcMwDES9j1fJKB2kg2ROt/fUoyDJHxiJXSAAH0BY/Oho0Y6RKUmSJEmSJEmSG1iW5fEzoNiX07uo7PtMXaDaWfb861B6PGUPpz8XDsFh7N6C9GcPrQ6M2N19/wUO9e5BNJvDtxH9o/xHczRABoPZ7fwYGqZ1Rf5cihv24i0qQTvoetLDbqdFXMZnoex1rPtUEAvkbvZ4CzXrvoE0d6qAL+NGu0GrtB6sXY8oHj/f3QGyH2Pd1G9qO1cHaL9+GqjH7FaItTpaX/MNRgQxu5twk6C6OgS5pwYI496RMY8Wmqy5ttptLXHZ+MDjhWBfq1nfyoD9Tr8ODRG3u4K8+708QPSpsbti1EYr6kfttpa4bPPerUFtecuoI1aSV0IDxO2uiJugOWuHu4OxxkpiA/azN+pBa36qdUixdrzWtjmvTw0QyIUO13bvZUhw9T9QxGG6p0Y8clwjx02xCVgTGyEu2/0fqFAZjik9gBrH2BMPYneASm/qAPWOF/CdSpIkSZIkSZKGafoFOAUyn0EkC0MAAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFEAAAAbCAYAAAAETGM8AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGRSURBVGhD7ZaJbcMwDEW9j1fJKB2kg2ROp/+pn4IkHzDqJEUAPoAwL5ES7QiZkiRJkiRJkiT5J5ZluT0G5PtyeBelfZ/JC5Q7S+6/HUqPu+Tm8GfDQTiQzZeg+rMHV4eG79V93wYHu3oYzefwq6T+UfzjORoiw0FsdnYMDpFekT2X5IY9f4tSqB10Pelhs6uFX8IVUdba110b+AKZmz0uo4bdncgGHCpgS9hsN2yl1sO1+oj88VPeHSLrEfQmf7O2Y3WItus1QT5is4KvrSP9eXcyhShocxM2Csqrg5B5aogwrh0Z49SiJjrPtnabi18yvvT4KFjX1qxfZ8B6h69BUxrYXEHcPf88ROqTY3PFWJtakT/WbnPxSzb37hrklq+NPHwl+GxoQgObK2IjbADd7u5w6EgJbMB61kY+SOdnWwcVuv01t41ZPzVEIBZ1eLZrn4qKrv4nijhQ9/bwR4xnxNgYiwAd3wh+ye7/RLnKgEzpAeTYx5p4GbtDVHizDpBvfwHboSRJkiRJkiRJ3s80/QDxOzKfHuanhQAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAAAaCAYAAAAg0tunAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGPSURBVGhD7ZaLbcMwDES9j1fJKB2kg2ROt/fUoyDJHxiJXSAAH0BY/Oho0Y6RKUmSJEmSJEmSG1iW5fEzoNiX07uo7PtMXaDaWfb861B6PGUPpz8XDsFh7N6C9GcPrQ6M2N19/wUO9e5BNJvDtxH9o/xHczRABoPZ7fwYGqZ1Rf5cihv24i0qQTvoetLDbqdFXMZnoex1rPtUEAvkbvZ4CzXrvoE0d6qAL+NGu0GrtB6sXY8oHj/f3QGyH2Pd1G9qO1cHaL9+GqjH7FaItTpaX/MNRgQxu5twk6C6OgS5pwYI496RMY8Wmqy5ttptLXHZ+MDjhWBfq1nfyoD9Tr8ODRG3u4K8+708QPSpsbti1EYr6kfttpa4bPPerUFtecuoI1aSV0IDxO2uiJugOWuHu4OxxkpiA/azN+pBa36qdUixdrzWtjmvTw0QyIUO13bvZUhw9T9QxGG6p0Y8clwjx02xCVgTGyEu2/0fqFAZjik9gBrH2BMPYneASm/qAPWOF/CdSpIkSZIkSZKGafoFOAUyn0EkC0MAAAAASUVORK5CYII="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 7.000000 1.000000 L 73.000000 1.000000 L 75.312500 1.500000 L 77.250000 2.750000 L 78.500000 4.687500 L 79.000000 7.000000 L 79.000000 19.000000 L 78.500000 21.312500 L 77.250000 23.250000 L 75.312500 24.500000 L 73.000000 25.000000 L 7.000000 25.000000 L 4.750000 24.562500 L 2.812500 23.250000 L 1.500000 21.312500 L 1.000000 19.000000 L 1.000000 7.000000 L 1.500000 4.687500 L 2.750000 2.750000 L 4.687500 1.500000 L 7.000000 1.000000 z"}
,
"button6428":{"x":416,"y":613,"w":34.000000,"h":18.000000,"stylemods":[{"sel":"div.button6428Text","decl":" { position:fixed; left:3px; top:3px; width:28px; height:12px;}"},{"sel":"span.button6428Text","decl":" { display:table-cell; position:relative; width:28px; height:12px; vertical-align:middle; text-align:center; line-height:10px; font-size:10px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAASCAYAAAA+PQxvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U9tDQ8gAACu1AAJogABPRq3GwAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAASCAYAAAA+PQxvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U9tDQ8gAACu1AAJogABPRq3GwAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACEAAAARCAYAAABTnsXCAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cEBDQAAAMKg909tDjcgAIB/NQjVAAEvKxesAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAASCAYAAAA+PQxvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U9tDQ8gAACu1AAJogABPRq3GwAAAABJRU5ErkJggg=="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 33.000000 9.000000 L 1.000000 17.000000 L 1.000000 1.000000 L 33.000000 9.000000 z"}
,
"button7184":{"x":454,"y":613,"w":34.000000,"h":18.000000,"stylemods":[{"sel":"div.button7184Text","decl":" { position:fixed; left:3px; top:3px; width:28px; height:12px;}"},{"sel":"span.button7184Text","decl":" { display:table-cell; position:relative; width:28px; height:12px; vertical-align:middle; text-align:center; line-height:10px; font-size:10px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAASCAYAAAA+PQxvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U9tDQ8gAACu1AAJogABPRq3GwAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAASCAYAAAA+PQxvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U9tDQ8gAACu1AAJogABPRq3GwAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACEAAAARCAYAAABTnsXCAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cEBDQAAAMKg909tDjcgAIB/NQjVAAEvKxesAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAASCAYAAAA+PQxvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U9tDQ8gAACu1AAJogABPRq3GwAAAABJRU5ErkJggg=="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 1.000000 9.000000 L 33.000000 17.000000 L 33.000000 1.000000 L 1.000000 9.000000 z"}
,
"image4524":{"x":0,"y":0,"w":192,"h":65,"bOffBottom":0,"i":"images/image0007.png"}
,
"image4544":{"x":589,"y":0,"w":131,"h":63,"bOffBottom":0,"i":"images/image0008.png"}
,
"shape10857":{"x":-1,"y":47,"w":784.000000,"h":6.000000,"stylemods":[{"sel":"div.shape10857Text","decl":" { position:fixed; left:3px; top:3px; width:776px; height:-2px;}"},{"sel":"span.shape10857Text","decl":" { display:table-cell; position:relative; width:776px; height:-2px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAw4AAAAECAYAAAAnMWi2AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAjSURBVGhD7cExAQAAAMKg9U9tDB8gAAAAAAAAAAAAAACAuxow5AABVlqDJgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 2.000000 4.000000 L 782.000000 2.000000 "}
,
"shape5926":{"x":772,"y":48,"w":11.000000,"h":601.000000,"stylemods":[{"sel":"div.shape5926Text","decl":" { position:fixed; left:3px; top:3px; width:3px; height:593px;}"},{"sel":"span.shape5926Text","decl":" { display:table-cell; position:relative; width:3px; height:593px; vertical-align:middle; text-align:center; line-height:39px; font-size:39px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAJXCAYAAABBin6+AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAsSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAB8qAFWkwABpVCECAAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 9.000000 2.000000 L 2.000000 599.000000 "}
,
"shape6013":{"x":-5,"y":643,"w":802.000000,"h":33.000000,"stylemods":[{"sel":"div.shape6013Text","decl":" { position:fixed; left:12px; top:12px; width:767px; height:-2px;}"},{"sel":"span.shape6013Text","decl":" { display:table-cell; position:relative; width:767px; height:-2px; vertical-align:middle; text-align:center; line-height:10px; font-size:10px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAw4AAAANCAYAAAAAPjl+AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA/SURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXtQAnuUAAbrl8P8AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 7.000000 9.000000 L 778.000000 7.000000 "}
,
"toc6304":{"x":0,"y":98,"w":177,"h":197,"fsize":16,"bOffBottom":0}
,
"shape7681":{"x":0,"y":49,"w":60.000000,"h":26.000000,"stylemods":[{"sel":"div.shape7681Text","decl":" { position:fixed; left:2px; top:2px; width:55px; height:21px;}"},{"sel":"span.shape7681Text","decl":" { display:table-cell; position:relative; width:55px; height:21px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Arial\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAAaCAYAAADrCT9ZAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cExAQAAAMKg9U9tCU8gAAAAAACAkxoYegAB+lNM6AAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 59.000000 25.000000 L 0.000000 25.000000 L 0.000000 0.000000 L 59.000000 0.000000 L 59.000000 25.000000 z"}
,
"shape7722":{"x":59,"y":49,"w":722.000000,"h":27.000000,"stylemods":[{"sel":"div.shape7722Text","decl":" { position:fixed; left:2px; top:2px; width:717px; height:22px;}"},{"sel":"span.shape7722Text","decl":" { display:table-cell; position:relative; width:717px; height:22px; vertical-align:middle; text-align:center; line-height:14px; font-size:14px; font-family:\"Times New Roman\"; font-weight:bold; color:#000000;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAtIAAAAbCAYAAABREmj/AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAM2SURBVHhe7dpbbtswEAXQ7Kdb6VK6kC6k+2w9HxcYDEhLcuwAjc8BCIcSHyP650bwBwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXPTz1v5u2u9bO+PHrc05v26t+vX5bNlr1Wr/qufII/XVun9uLXvV2UU/g12ruZ8xz3nuufPK7wIA4K31QFZ/9/7Z8FfBrsZ/RZAuc7+rNT9SX0J09loF6fos9Xe11FdjPxuky3zu/o/Qzu5ZX/XdAAC8jR5CEwQTvvq1e2bAe7XU1/frofJMzVdl7ZXarwfTjO31PeNs5jmfCdIrVesz6gEAeGvfJUhfrfmKfkZnZOyzz2Oe8yNBOnO+6rsCAPi2ZpDu/V1QrZ8p9LDaA96Z+dUq0GVeWs0982Z5Buk+p+5FrtW47NXr6PXVXvn5RrVaM3It7UjG9fXj3jmWe/fzDFm3P3epselX6/2a08en9ecEAOCCGb7SeghMuEtITaBLyJsBb/b7/Ow3x2btUuEua69kvdn6GiVrV8u+tfasL/fyO+YEztSQ+9XOyNisH/0cSurIPkf3Z909GEc9Qz+HOSd7pA8AwIN6SExgm+b9GcZmWJv9OX/K/ehBcGUVBnOt75NrCcixqzdvZ3MmuZ9+tTMyttdXcn13jkf3U2f6M0iv3nDPOauzAwDgAT0kzhBWVvdnQJ1hbfbn/Cnr1WeFw9242IXB7JPru3GzvnqOzO0tz7c6g3sytu+7WqOf49H9MuvuQTot/wzEnLM7EwAALloFuGnen2FshrXZz/yat3NmTKzCYH+OXN+Fxllf+ru9z5xRl7Fz37nGrO/ofupMvwfpXY1zzu5MAAC4aBfAuoSvvO1MOMv4GdZmP/P7nLrWZc58o7oy1681+1vlWWfGxbzeA2nm1mdqPHNGXcbOfY/O8eo597oj/blG5mSP6s/vAACAk3oQS9uFqwSwahVaE9R6yKw215whsFpCXVfj8hOGe/ras+UnEtHv5fqsN9dn3f0c+vVqO6vznON35xiPnnOd6RzTz7xa3a9W61Z/7g0AwH9qF+IBAIAmb1UrQK/eUgMAAAv9pwh+ZgAAAAAAAAAAAAAAAAAAAEB8fPwDtlIBP/N4xHgAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 721.000000 0.000000 L 721.000000 26.000000 L 0.000000 26.000000 L 0.000000 0.000000 z"}
,
"progress9833":{"x":610,"y":617,"w":143,"h":14,"bOffBottom":0,"vert":0,"barImage":"images/PhoneLandscape_progress9833_bar.png","bgImage":"images/PhoneLandscape_progress9833.png"}
,
"text14760":{"x":164,"y":344,"w":512,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14768":{"x":256,"y":381,"w":80,"h":20,"fsize":16,"bOffBottom":0}
,
"text14718":{"x":164,"y":300,"w":406,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14729":{"x":256,"y":319,"w":80,"h":20,"fsize":16,"bOffBottom":0}
,
"text14689":{"x":164,"y":257,"w":459,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14690":{"x":256,"y":276,"w":80,"h":20,"fsize":16,"bOffBottom":0}
,
"text14650":{"x":164,"y":214,"w":327,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14651":{"x":256,"y":234,"w":81,"h":19,"fsize":16,"bOffBottom":0}
,
"text14629":{"x":164,"y":171,"w":373,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14630":{"x":258,"y":148,"w":81,"h":17,"fsize":16,"bOffBottom":0}
,
"text14525":{"x":163,"y":86,"w":493,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14526":{"x":256,"y":105,"w":81,"h":17,"fsize":16,"bOffBottom":0}
,
"text14569":{"x":164,"y":128,"w":455,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14570":{"x":256,"y":192,"w":81,"h":18,"fsize":16,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/PhoneLandscape_progress9833.png','images/PhoneLandscape_progress9833_bar.png']
},
"480":{
"pageLayer":{"w":480,"h":807,"bgColor":"#ffffff"}
,
"button4670":{"x":29,"y":775,"w":50.000000,"h":16.000000,"stylemods":[{"sel":"div.button4670Text","decl":" { position:absolute; left:3px; top:3px; width:44px; height:10px;}"},{"sel":"span.button4670Text","decl":" { display:table-cell; position:relative; width:44px; height:10px; vertical-align:middle; text-align:center; line-height:6px; font-size:6px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAQCAYAAABUWyyMAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADDSURBVEhL7ZPRDYMwDESzD6tkFAbpIJ0z4LPukHFaqfzwQf0k62rnEjtAW1EUxTPYAiydGGO8o0astnLr9mn9VvIAym22l3KLnoe130vMBWr0rvDEc6QM3y8v1uBl3pFfAhuJGnY0sFiYHwNABX0+gIg1+C2mi6ARFNDjQ0ev9BJqIHBwavDtIv5EoSxp73QRKHLVocJyvG33mDrZ8xPc6+Awi2OQqLaMZnmI6T8CZa7PxdfiOjUOLq8+rVOfoij+jtZ2sIt31u8SoH8AAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAQCAYAAABUWyyMAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADDSURBVEhL7ZPRDYMwDESzD6tkFAbpIJ0z4LPukHFaqfzwQf0k62rnEjtAW1EUxTPYAiydGGO8o0astnLr9mn9VvIAym22l3KLnoe130vMBWr0rvDEc6QM3y8v1uBl3pFfAhuJGnY0sFiYHwNABX0+gIg1+C2mi6ARFNDjQ0ev9BJqIHBwavDtIv5EoSxp73QRKHLVocJyvG33mDrZ8xPc6+Awi2OQqLaMZnmI6T8CZa7PxdfiOjUOLq8+rVOfoij+jtZ2sIt31u8SoH8AAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADMAAAARCAYAAABwxZQXAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADESURBVEhL7ZPRDYMwDESzD6tkFAbpIMwZ8Fl3yDitVH74QH6SdbVziR2grSiK4t3sAZYujDG2qBGrrdy6f1t/nDyEcpvvo9yi54Ht9xJzgRq9KzzxHCnD98uLNXiZd+S3wWaiph1NLBbm5xBQQZ8PIWINfovpMmgEBfT44NErvY2aCByemvy6jD9ZKEvaO10Gilx1qLAcb909pk72/A33OzjQ4hwmqi2jYR5k+s9AmevT8bW4To3Dy6vP7NKnKIrijbR2ALWod9ZBP8GjAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAQCAYAAABUWyyMAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADDSURBVEhL7ZPRDYMwDESzD6tkFAbpIJ0z4LPukHFaqfzwQf0k62rnEjtAW1EUxTPYAiydGGO8o0astnLr9mn9VvIAym22l3KLnoe130vMBWr0rvDEc6QM3y8v1uBl3pFfAhuJGnY0sFiYHwNABX0+gIg1+C2mi6ARFNDjQ0ev9BJqIHBwavDtIv5EoSxp73QRKHLVocJyvG33mDrZ8xPc6+Awi2OQqLaMZnmI6T8CZa7PxdfiOjUOLq8+rVOfoij+jtZ2sIt31u8SoH8AAAAASUVORK5CYII="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 4.000000 1.000000 L 46.000000 1.000000 L 47.187500 1.250000 L 48.125000 1.875000 L 48.750000 2.875000 L 49.000000 4.000000 L 49.000000 12.000000 L 48.750000 13.187500 L 48.125000 14.125000 L 47.187500 14.750000 L 46.000000 15.000000 L 4.000000 15.000000 L 2.875000 14.750000 L 1.937500 14.125000 L 1.250000 13.187500 L 1.000000 12.000000 L 1.000000 4.000000 L 1.250000 2.875000 L 1.875000 1.875000 L 2.875000 1.250000 L 4.000000 1.000000 z"}
,
"button6428":{"x":256,"y":780,"w":22.000000,"h":12.000000,"stylemods":[{"sel":"div.button6428Text","decl":" { position:fixed; left:3px; top:3px; width:16px; height:6px;}"},{"sel":"span.button6428Text","decl":" { display:table-cell; position:relative; width:16px; height:6px; vertical-align:middle; text-align:center; line-height:6px; font-size:6px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAMCAYAAABm+U3GAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAATSURBVDhPYxgFo2AUjAKCgIEBAAQsAAEB/NPrAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAMCAYAAABm+U3GAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAATSURBVDhPYxgFo2AUjAKCgIEBAAQsAAEB/NPrAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAALCAYAAACQy8Z9AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAASSURBVDhPYxgFo2AUDG7AwAAAA6cAATQYrxwAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAMCAYAAABm+U3GAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAATSURBVDhPYxgFo2AUjAKCgIEBAAQsAAEB/NPrAAAAAElFTkSuQmCC"  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 21.000000 6.000000 L 1.000000 11.000000 L 1.000000 1.000000 L 21.000000 6.000000 z"}
,
"button7184":{"x":279,"y":780,"w":22.000000,"h":12.000000,"stylemods":[{"sel":"div.button7184Text","decl":" { position:fixed; left:3px; top:3px; width:16px; height:6px;}"},{"sel":"span.button7184Text","decl":" { display:table-cell; position:relative; width:16px; height:6px; vertical-align:middle; text-align:center; line-height:6px; font-size:6px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAMCAYAAABm+U3GAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAATSURBVDhPYxgFo2AUjAKCgIEBAAQsAAEB/NPrAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAMCAYAAABm+U3GAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAATSURBVDhPYxgFo2AUjAKCgIEBAAQsAAEB/NPrAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAALCAYAAACQy8Z9AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAASSURBVDhPYxgFo2AUDG7AwAAAA6cAATQYrxwAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAMCAYAAABm+U3GAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAATSURBVDhPYxgFo2AUjAKCgIEBAAQsAAEB/NPrAAAAAElFTkSuQmCC"  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 1.000000 6.000000 L 21.000000 11.000000 L 21.000000 1.000000 L 1.000000 6.000000 z"}
,
"image4524":{"x":0,"y":0,"w":117,"h":40,"bOffBottom":0,"i":"images/image0007.png"}
,
"image4544":{"x":360,"y":0,"w":80,"h":38,"bOffBottom":0,"i":"images/image0008.png"}
,
"shape10857":{"x":-1,"y":68,"w":477.000000,"h":4.000000,"stylemods":[{"sel":"div.shape10857Text","decl":" { position:fixed; left:3px; top:3px; width:469px; height:-4px;}"},{"sel":"span.shape10857Text","decl":" { display:table-cell; position:relative; width:469px; height:-4px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdsAAAACCAYAAAAQPHZnAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAbSURBVEhL7cEBDQAAAMKg909tDjcgAAAAOFYDDtoAAZR/108AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 2.000000 2.000000 L 475.000000 2.000000 "}
,
"shape5926":{"x":472,"y":68,"w":8.000000,"h":742.000000,"stylemods":[{"sel":"div.shape5926Text","decl":" { position:fixed; left:3px; top:3px; width:0px; height:734px;}"},{"sel":"span.shape5926Text","decl":" { display:table-cell; position:relative; width:0px; height:734px; vertical-align:middle; text-align:center; line-height:39px; font-size:39px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAALkCAYAAAAs30ToAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAApSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAADgUA1IRAABiVoovgAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 6.000000 2.000000 L 2.000000 740.000000 "}
,
"shape6013":{"x":-5,"y":799,"w":503.000000,"h":34.000000,"stylemods":[{"sel":"div.shape6013Text","decl":" { position:fixed; left:12px; top:12px; width:468px; height:-1px;}"},{"sel":"span.shape6013Text","decl":" { display:table-cell; position:relative; width:468px; height:-1px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAeMAAAAOCAYAAAAc2nTQAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAwSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdqabYAAQlzOncAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 7.000000 10.000000 L 479.000000 7.000000 "}
,
"toc6304":{"x":0,"y":130,"w":143,"h":198,"fsize":16,"bOffBottom":0}
,
"shape7681":{"x":0,"y":69,"w":37.000000,"h":16.000000,"stylemods":[{"sel":"div.shape7681Text","decl":" { position:fixed; left:2px; top:2px; width:32px; height:11px;}"},{"sel":"span.shape7681Text","decl":" { display:table-cell; position:relative; width:32px; height:11px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Arial\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAAQCAYAAACRKbYdAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCF8gAAAONQlQAAH88N2BAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 36.000000 15.000000 L 0.000000 15.000000 L 0.000000 0.000000 L 36.000000 0.000000 L 36.000000 15.000000 z"}
,
"shape7722":{"x":36,"y":68,"w":440.000000,"h":17.000000,"stylemods":[{"sel":"div.shape7722Text","decl":" { position:fixed; left:2px; top:2px; width:435px; height:12px;}"},{"sel":"span.shape7722Text","decl":" { display:table-cell; position:relative; width:435px; height:12px; vertical-align:middle; text-align:center; line-height:8px; font-size:8px; font-family:\"Times New Roman\"; font-weight:bold; color:#000000;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAbgAAAARCAYAAACvrrkhAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGwSURBVHhe7dfRbcMwDEXR7NNVOkoH6SDds/X9eMADwaTOn9vcAxBWRJmWfkTkJkmSJEmSJEmSJEmSJEmv5uOI7wp+b96P6PznEffWbvJ+x9cR9/xWn3zqvB3xbP3WZ8uYZ5v7mXlJ0gXRCPpyv+fZpjZRP02HppTvPot32SfPoHYi32C/Z/XZtgbXWPsoL0m6iK3B8ZsxuTSSNIGsS0PotUQaROpG5pAGx1waFvX7OevzzNpENzn0N9B7y9ptbmtwvY88mWdMzG9Lki6Giz6Xdl/yXODdMLoJZMwa1jbWpxm0bg5E6oIxNWPW7+9s34zeL/Juz29zfTby5BLY8pKki+OSz+WNbiD3mkDG5LM2mOed2QS6FhhTB3MPs36CvZ1tcNs5zpyNPOPsDTPPu5Kki5vNJU2AJ/NbE8g4a7nw+9LP+60bCjnG+T33MOt3rcxt5jfmObY5zAaWXM5kg5OkP4ZLmws7l35kPk2BCz3r5jtc/ox5Ro/R7ydSm8hv9NqtfnJZH6nTuXkOnDkbuXyXcfKs5zchSXpB/sORJP0r+QeUf0uSJEmSJEmSJEmP3W4/3ojKFmyq8hMAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 0.000000 0.000000 L 439.000000 0.000000 L 439.000000 16.000000 L 0.000000 16.000000 L 0.000000 0.000000 z"}
,
"progress9833":{"x":374,"y":779,"w":87,"h":9,"bOffBottom":0,"vert":0,"barImage":"images/PhonePortrait_progress9833_bar.png","bgImage":"images/PhonePortrait_progress9833.png"}
,
"text14760":{"x":143,"y":477,"w":347,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14768":{"x":151,"y":524,"w":80,"h":20,"fsize":16,"bOffBottom":0}
,
"text14718":{"x":147,"y":418,"w":347,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14729":{"x":149,"y":443,"w":80,"h":20,"fsize":16,"bOffBottom":0}
,
"text14689":{"x":143,"y":338,"w":329,"h":76,"txtscale":100,"bOffBottom":0}
,
"combo14690":{"x":148,"y":387,"w":80,"h":20,"fsize":16,"bOffBottom":0}
,
"text14650":{"x":148,"y":289,"w":347,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14651":{"x":150,"y":309,"w":84,"h":19,"fsize":16,"bOffBottom":0}
,
"text14629":{"x":146,"y":235,"w":347,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14630":{"x":150,"y":259,"w":83,"h":17,"fsize":16,"bOffBottom":0}
,
"text14525":{"x":149,"y":119,"w":347,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14526":{"x":150,"y":147,"w":81,"h":17,"fsize":16,"bOffBottom":0}
,
"text14569":{"x":151,"y":171,"w":347,"h":38,"txtscale":100,"bOffBottom":0}
,
"combo14570":{"x":152,"y":200,"w":82,"h":20,"fsize":16,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/PhonePortrait_progress9833.png','images/PhonePortrait_progress9833_bar.png']
}}
